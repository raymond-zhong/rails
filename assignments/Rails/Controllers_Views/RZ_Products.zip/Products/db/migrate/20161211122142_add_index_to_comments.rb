class AddIndexToComments < ActiveRecord::Migration
  def change
  end
end
