class Comment < ActiveRecord::Base
  belongs_to :product
end
